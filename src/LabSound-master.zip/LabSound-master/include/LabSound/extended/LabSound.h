// License: BSD 2 Clause
// Copyright (C) 2015+, The LabSound Authors. All rights reserved.

#pragma once

#ifndef LABSOUND_EXTENDED_H
#define LABSOUND_EXTENDED_H

#include "LabSound/LabSound.h"

#endif
