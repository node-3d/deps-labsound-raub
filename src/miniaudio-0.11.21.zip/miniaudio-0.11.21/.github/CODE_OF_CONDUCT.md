Code of Conduct
===============
We don't believe we need a document telling fully grown adults how to conduct themselves within an open source
community. All we ask is that you just don't be unpleasant and keep everything on topic.
