---
name: Feature request
about: Submit a feature request.
title: ''
labels: feature request
assignees: ''

---

**DELETE ALL OF THIS TEXT BEFORE SUBMITTING**

Thanks for your suggestion! Please make sure the feature doesn't already exist and that it's within the scope of the goals of the project. Otherwise go into as much detail as possible and we'll consider it!
