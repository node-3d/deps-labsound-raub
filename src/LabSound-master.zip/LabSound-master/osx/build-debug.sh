#!/bin/sh
xcodebuild -project osx/LabSound.xcodeproj -target LabSound -configuration Debug 

